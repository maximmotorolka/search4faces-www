<?php

require __DIR__ . '/vendor/autoload.php';
use JsonRPC\Client; //https://github.com/matasarei/JsonRPC

$apiUrl = "https://search4faces.com/api/json-rpc/v1";
$apiKey = "";

if ($argc <= 1) {
    die("Missing source .jpeg or .png file name");
}
$sourceImage = @file_get_contents($argv[1]);
if ($sourceImage === false) {
    die("Cannot access '" . $argv[1] . "' file to read contents.");
}
if ((substr($sourceImage, 0, 3) != "\xFF\xD8\xFF") && (substr($sourceImage, 0, 8) != "\x89\x50\x4E\x47\x0D\x0A\x1A\x0A")) {
    die("Source file is not a valid .jpeg or .png image");
}

$client = new Client($apiUrl);
$client->getHttpClient()->withBeforeRequestCallback(function (JsonRPC\HttpClient $client, $payload) {
    global $apiKey;
    $client->withHeaders([
        "Content-Type: application/json",
        "x-authorization-token: {$apiKey}"
    ]);
});

/*
$result = $client->execute('rateLimit', array());
print_r($result);
echo json_encode($result);
*/

$detectFaces = $client->execute('detectFaces', array("image" => base64_encode($sourceImage)));
for ($i = 0; $i < count($detectFaces['faces']); $i++) {
    $searchFace = $client->execute('searchFace', array("image" => $detectFaces['image'],"face" => $detectFaces['faces'][$i],"source" => "vk_wall", "results" => 2, "hidden" => true));
    print_r($searchFace);
};
