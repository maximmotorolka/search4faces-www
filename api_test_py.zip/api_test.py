import sys
import base64
from pprint import pprint
#https://github.com/bcb/jsonrpcclient
from jsonrpcclient import request 
from jsonrpcclient.clients.http_client import HTTPClient

apiUrl = "https://search4faces.com/api/json-rpc/v1";
apiKey = "";

client = HTTPClient(apiUrl)
client.session.headers.update({"Content-Type": "application/json-rpc","x-authorization-token": apiKey})

#response = client.request("rateLimit")
#print(response.data.result)

if len(sys.argv) <= 1:
    sys.exit("Missing source .jpeg or .png file name")

image = open(sys.argv[1], 'rb')
image_read = image.read()
if ((image_read[:3] != b'\xff\xd8\xff') and (image_read[:8] != b'\x89\x50\x4E\x47\x0D\x0A\x1A\x0A')):
    sys.exit("Source file is not a valid .jpeg or .png image")
image_64_encode = base64.b64encode(image_read).decode("ascii")

response = client.request("detectFaces", image=image_64_encode)
detectFaces = response.data.result
for i in range(0, len(detectFaces['faces'])):
   response = client.request("searchFace", image = detectFaces["image"], face = detectFaces["faces"][i], source = "vk_wall", results = 2, hidden = True)
   searchFace = response.data.result
   pprint(searchFace,sort_dicts=False)